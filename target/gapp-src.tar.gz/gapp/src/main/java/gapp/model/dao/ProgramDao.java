package gapp.model.dao;


import gapp.model.Program;

import java.util.List;

public interface ProgramDao {
	
	
	    public List<Program> listProgram();
	    public Program getProgramById(int programid);
	    public List<Program> listProgram(int departmentid);
	    Program addProgram(Program program);
	    Program saveProgram(Program program);
	    void remove(Program program);
	    
}
