package gapp.model.dao;
import java.util.List;

import gapp.model.CustomField;
import gapp.model.Program;



	public interface CustormFieldDao {
		
		public List<CustomField> listCustomfield();
		public CustomField getCustomformById(int controlid);
		public List<CustomField> getCustomFormByProgram(int programid);
		CustomField addadditional(CustomField additional);
		public List<CustomField> getCustomFormByDepartment(int departmentid);
		CustomField save(CustomField additional);
		 void removeCustom(CustomField additional);
	}



