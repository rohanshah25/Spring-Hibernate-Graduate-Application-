drop table academicrecord CASCADE;

drop table customdata CASCADE;
drop table customvalue CASCADE;
drop table department CASCADE;
drop table educationalinfo CASCADE;
drop table program CASCADE;
drop table rolevalues CASCADE;
drop table status CASCADE;
drop table application CASCADE;
drop table students CASCADE;
drop table users CASCADE;



drop sequence hibernate_sequence;
