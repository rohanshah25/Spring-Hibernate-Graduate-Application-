package gapp.model.dao;

import gapp.model.Department;

import java.util.List;

public interface DepartmentDAO {

	 public List<Department> getDepartments();
	 public Department getDepartmentById(int departmentid);
	 Department addDepartment(Department department);
	 Department saveDepartment(Department department);
	
}
