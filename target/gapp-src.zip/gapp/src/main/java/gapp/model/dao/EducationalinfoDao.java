package gapp.model.dao;

import gapp.model.Academicrecord;
import gapp.model.Educationalinfo;

import java.util.List;

public interface EducationalinfoDao {
	
	
	public List<Educationalinfo> listEducationalinfo();
    
    public Educationalinfo getEducationalinfoById(int educationalid);
    public List<Educationalinfo> getEducationalByStudentId(int studentid);
    public Educationalinfo saveeducational(Educationalinfo educationalinfo);
    public void removeEducationalinfo(int educationalid);
    
}
